package com.example.sogating_final.message

data class MsgModel (
    val senderInfo : String = "",
    val sendTxt : String = ""
)