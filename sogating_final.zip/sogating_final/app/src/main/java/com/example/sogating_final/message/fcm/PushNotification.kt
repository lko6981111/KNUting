package com.example.sogating_final.message.fcm

class PushNotification (
    val data : NotiModel,
    val to : String
)