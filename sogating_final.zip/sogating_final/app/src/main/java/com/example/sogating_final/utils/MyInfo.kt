package com.example.sogating_final.utils

class MyInfo {

    companion object {

        var myNickname : String = ""

    }
}