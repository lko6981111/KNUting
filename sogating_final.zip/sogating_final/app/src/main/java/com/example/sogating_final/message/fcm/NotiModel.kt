package com.example.sogating_final.message.fcm

data class NotiModel (
    val title : String = "",
    val content : String = ""
)
