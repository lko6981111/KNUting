package com.example.sogating_final.message.fcm

class Repo {

    companion object {

        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAAo2pfH6s:APA91bEgURPqUU8y5KA6-OArUPqlW0wE_Jp_I1wWgCgW6ZtBlBaku4tCBa1ROhC6mCR_9F9XApnV8WQTPbaSz-BV4UV6GkvqEy08zNnoNgqMSwLO7cfXf5-uyVkSsUESJGC-NAWz66dW"
        const val CONTENT_TYPE = "application/json"

    }

}